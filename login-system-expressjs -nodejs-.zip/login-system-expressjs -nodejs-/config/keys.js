module.exports ={
    mongoURI: 'mongodb://localhost:27017://YOURUSERNAME:YOURUSERPASSWORD@cluster0.6ezn5.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}